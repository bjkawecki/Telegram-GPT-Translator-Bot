def handler(event, context):
    return "Hello from initial Lambda."
